package com.lambdacode.spring.boot.crud.DAO;

public class CoordenadaDAO {
}
