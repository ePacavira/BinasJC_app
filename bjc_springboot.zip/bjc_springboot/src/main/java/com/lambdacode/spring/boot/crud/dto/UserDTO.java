package com.lambdacode.spring.boot.crud.dto;

import lombok.Data;

@Data
public class UserDTO {
    private String nome;
}
